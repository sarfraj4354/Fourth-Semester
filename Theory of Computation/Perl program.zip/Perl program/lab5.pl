#!C:\Perl64\bin\perl.exe
#input from user example 
print "enter your birth year :";
$year = <STDIN>;
$age = 2025-$year;
print"\n your age is:$age";