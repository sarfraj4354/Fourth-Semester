#!C:\Perl64\bin\perl.exe
# perl scalar example 
my $age =20;  # an ineger assignment
my $name ="Sarfraj Alam";  # string
my $marks =78.50;  # floating point

print "Age =$age\n";
print "Name =$name\n";
print "marks= $marks\n";