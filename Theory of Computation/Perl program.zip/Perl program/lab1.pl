#!C:\Perl64\bin\perl.exe

# my first program
print"\nHello,welcome to the perl world\n";